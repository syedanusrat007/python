#Fast Food
VERSION = '' #1.0
#By Tyler Spadgenske
#https://github.com/spadgenske/Fast-Food
#Copyright 2014(c)

import pygame, sys, os, random, time
from pygame.locals import *
from menu import Menu
from blit_burger import *
from gen import Gen
from clock import Clock
from fade import Fade


pygame.init()
#Constants
NUM_OF_ORDERS = 6
DIFFICULTY = 5
class Main():
    def __init__(self):
        
        self.ROOT_PATH = os.path.abspath('images')
        self.SOUND_ROOT_PATH = os.path.abspath('sound')

        self.WINDOW_WIDTH = 800
        self.WINDOW_HIEGHT = 480
        os.environ ['SDL_VIDEO_WINDOW_POS'] = 'center'
        self.surface = pygame.display.set_mode((self.WINDOW_WIDTH, self.WINDOW_HIEGHT), 0, 32)
        pygame.display.set_icon(pygame.image.load(os.path.join(self.ROOT_PATH, 'burger.ico')))
        pygame.display.set_caption('Fast Food ' + VERSION)
        self.clock = pygame.time.Clock()

        #Setup colors
        self.BLUE = (0,0,255)
        self.WHITE = (255, 255, 255)
        self.BLACK = (0,0,0)
        self.GREEN = (0,255,0)
        self.GAME_RED = (170,0,0)
        self.GRAY = (153, 153, 153)
        

        #Setup fonts
        self.Font = pygame.font.SysFont(None, 18)
        self.text_font = pygame.font.SysFont(None, 50)
        
        self.happiness = self.GREEN
        
        self.surface.fill(self.WHITE)
        
        #Create top rect for top bar
        self.top_bar = {'rect':pygame.Rect(0, 0, 800, 150),'color':self.GAME_RED}
        pygame.draw.rect(self.surface, self.top_bar['color'], self.top_bar['rect'])

        self.burger = pygame.image.load(os.path.join(self.ROOT_PATH, 'burger.png'))
        self.burger_rect = self.burger.get_rect()
        self.burger_rect.centery = self.surface.get_rect().centery - 30
        self.burger_rect.centerx = self.surface.get_rect().centerx
        self.start_time = time.time()
        self.total_time = 0

        self.start = self.text_font.render('Press Enter to Start', True, self.GAME_RED, self.WHITE)
        self.startRect = self.start.get_rect()
        self.startRect.centerx = self.surface.get_rect().centerx
        self.startRect.centery = self.surface.get_rect().centery + 50

        self.copyright = self.Font.render('copyright 2014(c) Tyler Spadgenske', True, self.GRAY, self.WHITE)
        self.copyrightRect = self.copyright.get_rect()
        self.copyrightRect.centerx = self.surface.get_rect().centerx
        self.copyrightRect.centery = self.surface.get_rect().centery + 225
        
        self.exit = False

        #Sound
        self.correct = pygame.mixer.Sound(os.path.join(self.SOUND_ROOT_PATH, 'correct.wav'))
        self.game_over = pygame.mixer.Sound(os.path.join(self.SOUND_ROOT_PATH, 'game_over.wav'))
        self.wrong = pygame.mixer.Sound(os.path.join(self.SOUND_ROOT_PATH, 'wrong.wav'))
        self.complete = pygame.mixer.Sound(os.path.join(self.SOUND_ROOT_PATH, 'complete.wav'))
        
    def compare(self, orders, burger, completed):
        if menu.order_clicked != None:
            if orders[menu.order_clicked] == burger:
                completed += 1
                menu.completed_customers -= 1
                if menu.completed_customers != 0:
                    self.correct.play()
                orders[menu.order_clicked] = generate.generate()
                burger = []
                menu.order_clicked = None
            elif orders[menu.order_clicked] != burger:
                self.wrong.play()
        return completed, burger

    def load(self):
        while True:
            self.surface.blit(self.copyright, self.copyrightRect)
            if time.time() - self.start_time > .5:
                pygame.draw.circle(self.surface, self.GAME_RED, (360, 265), 5, 0)
            if time.time() - self.start_time > 1:
                pygame.draw.circle(self.surface, self.GAME_RED, (380, 265), 5, 0)
            if time.time() - self.start_time > 1.5:
                pygame.draw.circle(self.surface, self.GAME_RED, (400, 265), 5, 0)
            if time.time() - self.start_time > 2:
                pygame.draw.circle(self.surface, self.GAME_RED, (420, 265), 5, 0)
            if time.time() - self.start_time > 2.5:
                pygame.draw.circle(self.surface, self.GAME_RED, (440, 265), 5, 0)
            if time.time() - self.start_time > 3:
                self.start_time = time.time()
                self.total_time += 1

            if self.total_time == 3:
                break
                
            pygame.display.update()
            game.surface.fill(game.WHITE)
            game.clock.tick()
            self.surface.blit(self.burger, self.burger_rect)
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()

    def menu(self):
        while True:
            pygame.display.update()
            game.surface.fill(game.WHITE)
            game.clock.tick()
            self.surface.blit(self.start, self.startRect)
            self.surface.blit(self.burger, self.burger_rect)
            for event in pygame.event.get():
                if event.type == KEYDOWN:
                    if event.key == 13:
                        self.exit = True
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()

            if self.exit:
                self.exit = False
                break

            
                
level = 0
game = Main()
game.load()
completed = 0
quit = False
while True:
    completed = 0
    level = 0
    game.menu()
    while True:
        #Setup for new level
        clock = Clock()
        game = Main()
        menu = Menu(game.surface)
        blit = Blit_Burger(game.surface)
        mode = 'burger'
        generate = Gen()
        orders = [generate.generate(), generate.generate(), generate.generate(), generate.generate(), generate.generate(), generate.generate()]
        burger = []
        blit_time = [0,0]
        new_level = True

        begin = Fade(game.surface)
        level = begin.start_new_level(level)    

        menu.completed_customers = level * DIFFICULTY
        seconds = level * (30 - level * (DIFFICULTY / 2))
        minutes = seconds / 60
        seconds = seconds - minutes * 60
        #print minutes, seconds

        clock.minutes = minutes
        clock.seconds = seconds

        first = False
        while True:
            if mode == 'burger':
                if first:
                    burger = []
                    first = False
            else:
                burger = []
                first = True
            
            menu.blit_orders()
            menu.bottom_menu(clock.blit_time, menu.completed_customers, completed)
            mode = menu.burger_menu(mode)
            mode = menu.soda_menu(mode)
            mode = menu.fries_menu(mode)
            burger = menu.select(mode, burger)
            blit.blit_burger(burger)

            completed, burger = game.compare(orders, burger, completed)
            #Blit orders
            for i in range(0,6):
                blit.small_blit_burger(i, orders[i])
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()

                mode = menu.burger_menu(mode, event)
                mode = menu.soda_menu(mode, event)
                mode = menu.fries_menu(mode, event)
                burger = menu.select(mode, burger, event)
                menu.order_button(event)
        
            pygame.display.update()
            game.surface.fill(game.WHITE)
            game.clock.tick()

            clock.time()

            if menu.completed_customers == 0:
                game.complete.play()
                break

            if clock.blit_time[0] == 0 and clock.blit_time[1] == 0:
                game.game_over.play()
                begin.game_over(completed)
                quit = True
                break

        if quit:
            quit = False
            break
