#Clock
#By Tyler Spadgenske

import time

class Clock():
    def __init__(self):
        #time stuff
        self.seconds = 0
        self.minutes = 1
        self.last_time = 0
        self.start_time = time.time()
        self.blit_time = [0,0]

    def time(self):
        self.current_time = time.time() - self.start_time

        if int(self.current_time) > int(self.last_time):
            self.seconds -= 1
            self.last_time = int(self.current_time)
            if self.seconds == -1:
                self.seconds = 59
                self.minutes -= 1
        self.blit_time = [self.minutes, self.seconds]
