#Buger Bliting
#By Tyler Spadgenske

import pygame, sys, os
from pygame.locals import *

pygame.init()

class Blit_Burger():
    def __init__(self, surface):
        self.ROOT_PATH = os.path.abspath('images')
        self.surface = surface
        #Create bun bottom image
        self.bun_bottom = pygame.image.load(os.path.join(self.ROOT_PATH, 'bun-bottom.png'))
        self.bun_bottom_rect = self.bun_bottom.get_rect()
        self.bun_bottom_rect.y = 340
        self.bun_bottom_rect.centerx = self.surface.get_rect().centerx - 40

        #Create small bun bottom image
        self.small_bun_bottom = pygame.transform.scale(self.bun_bottom, (100, 16))
        self.small_bun_bottom_rect = self.small_bun_bottom.get_rect()
        self.small_bun_bottom_rect.centerx = 90

        #Create tomato image
        self.tomato = pygame.image.load(os.path.join(self.ROOT_PATH, 'tomato.png'))
        self.tomato_rect = self.tomato.get_rect()
        self.tomato_rect.y = 340
        self.tomato_rect.centerx = self.surface.get_rect().centerx - 40

        #Create small tomato image
        self.small_tomato = pygame.transform.scale(self.tomato, (100, 8))
        self.small_tomato_rect = self.small_tomato.get_rect()
        self.small_tomato_rect.centerx = 90

        #Create pattie image
        self.pattie = pygame.image.load(os.path.join(self.ROOT_PATH, 'pattie.png'))
        self.pattie_rect = self.pattie.get_rect()
        self.pattie_rect.y = 340
        self.pattie_rect.centerx = self.surface.get_rect().centerx - 40

        #Create small pattie image
        self.small_pattie = pygame.transform.scale(self.pattie, (100, 7))
        self.small_pattie_rect = self.small_pattie.get_rect()
        self.small_pattie_rect.centerx = 90

        #Create lettuce image
        self.lettuce = pygame.image.load(os.path.join(self.ROOT_PATH, 'lettuce.png'))
        self.lettuce_rect = self.lettuce.get_rect()
        self.lettuce_rect.y = 340
        self.lettuce_rect.centerx = self.surface.get_rect().centerx - 40

        #Create small lettuce image
        self.small_lettuce = pygame.transform.scale(self.lettuce, (100, 13))
        self.small_lettuce_rect = self.small_lettuce.get_rect()
        self.small_lettuce_rect.centerx = 90

        #Create pickle image
        self.pickle = pygame.image.load(os.path.join(self.ROOT_PATH, 'pickle.png'))
        self.pickle_rect = self.pickle.get_rect()
        self.pickle_rect.y = 340
        self.pickle_rect.centerx = self.surface.get_rect().centerx - 40

        #Create small pickle image
        self.small_pickle = pygame.transform.scale(self.pickle, (100, 7))
        self.small_pickle_rect = self.small_pickle.get_rect()
        self.small_pickle_rect.centerx = 90

        #Create cheese image
        self.cheese = pygame.image.load(os.path.join(self.ROOT_PATH, 'cheese.png'))
        self.cheese_rect = self.cheese.get_rect()
        self.cheese_rect.y = 340
        self.cheese_rect.centerx = self.surface.get_rect().centerx - 40

        #Create small cheese image
        self.small_cheese = pygame.transform.scale(self.cheese, (100, 14))
        self.small_cheese_rect = self.small_cheese.get_rect()
        self.small_cheese_rect.centerx = 90

        #Create bun_top image
        self.bun_top = pygame.image.load(os.path.join(self.ROOT_PATH, 'bun.png'))
        self.bun_top_rect = self.bun_top.get_rect()
        self.bun_top_rect.y = 340
        self.bun_top_rect.centerx = self.surface.get_rect().centerx - 40

        #Create small bun_top image
        self.small_bun_top = pygame.transform.scale(self.bun_top, (100, 39))
        self.small_bun_top_rect = self.small_bun_top.get_rect()
        self.small_bun_top_rect.centerx = 90

        #############################
        #Onto soda blitting oh joy
        #Create red_soda image
        self.red_soda = pygame.image.load(os.path.join(self.ROOT_PATH, 'red.png'))
        self.red_soda = pygame.transform.scale(self.red_soda, (35, 65))
        self.red_soda_rect = self.red_soda.get_rect()
        self.red_soda_rect.y = 30

        #Create Blue Soda Image
        self.blue_soda = pygame.image.load(os.path.join(self.ROOT_PATH, 'blue.png'))
        self.blue_soda = pygame.transform.scale(self.blue_soda, (35, 65))

        #Create yellow Soda Image
        self.yellow_soda = pygame.image.load(os.path.join(self.ROOT_PATH, 'yellow.png'))
        self.yellow_soda = pygame.transform.scale(self.yellow_soda, (35, 65))

        #Create orange Soda Image
        self.orange_soda = pygame.image.load(os.path.join(self.ROOT_PATH, 'orange.png'))
        self.orange_soda = pygame.transform.scale(self.orange_soda, (35, 65))

        #Create purple Soda Image
        self.purple_soda = pygame.image.load(os.path.join(self.ROOT_PATH, 'purple.png'))
        self.purple_soda = pygame.transform.scale(self.purple_soda, (35, 65))

        #Create green Soda Image
        self.green_soda = pygame.image.load(os.path.join(self.ROOT_PATH, 'green.png'))
        self.green_soda = pygame.transform.scale(self.green_soda, (35, 65))

        ##################################
        #Fries blitting
        self.large_fries = pygame.image.load(os.path.join(self.ROOT_PATH, 'large.png'))
        self.large_fries = pygame.transform.scale(self.large_fries, (51, 67))
        self.large_fries_rect = self.large_fries.get_rect()
        self.large_fries_rect.y = 30

        #Create medium fries Image
        self.medium_fries = pygame.image.load(os.path.join(self.ROOT_PATH, 'medium.png'))
        self.medium_fries = pygame.transform.scale(self.medium_fries, (51, 67))

        #Create small fries Image
        self.small_fries = pygame.image.load(os.path.join(self.ROOT_PATH, 'small.png'))
        self.small_fries = pygame.transform.scale(self.small_fries, (51, 67))        

    def blit_burger(self, burger):
        if len(burger) > 0:
            if burger[0] == 'bun':
                self.bun_bottom_rect.y = 340
                self.surface.blit(self.bun_bottom, self.bun_bottom_rect)
            if burger[0] == 'tomato':
                self.tomato_rect.y = 340
                self.surface.blit(self.tomato, self.tomato_rect)
            if burger[0] == 'pattie':
                self.pattie_rect.y = 340
                self.surface.blit(self.pattie, self.pattie_rect)
            if burger[0] == 'lettuce':
                self.lettuce_rect.y = 340
                self.surface.blit(self.lettuce, self.lettuce_rect)
            if burger[0] == 'pickle':
                self.pickle_rect.y = 340
                self.surface.blit(self.pickle, self.pickle_rect)
            if burger[0] == 'cheese':
                self.cheese_rect.y = 340
                self.surface.blit(self.cheese, self.cheese_rect)
        if len(burger) > 1:
            if burger[1] == 'bun':
                self.bun_top_rect.y = 260
                self.surface.blit(self.bun_top, self.bun_top_rect)
            if burger[1] == 'tomato':
                self.tomato_rect.y = 325
                self.surface.blit(self.tomato, self.tomato_rect)
            if burger[1] == 'pattie':
                self.pattie_rect.y = 325
                self.surface.blit(self.pattie, self.pattie_rect)
            if burger[1] == 'lettuce':
                self.lettuce_rect.y = 320
                self.surface.blit(self.lettuce, self.lettuce_rect)
            if burger[1] == 'pickle':
                self.pickle_rect.y = 325
                self.surface.blit(self.pickle, self.pickle_rect)
            if burger[1] == 'cheese':
                self.cheese_rect.y = 320
                self.surface.blit(self.cheese, self.cheese_rect)
                
        if len(burger) > 2:
            if burger[2] == 'bun':
                self.bun_top_rect.y = 240
                self.surface.blit(self.bun_top, self.bun_top_rect)
            if burger[2] == 'tomato':
                self.tomato_rect.y = 305
                self.surface.blit(self.tomato, self.tomato_rect)
            if burger[2] == 'pattie':
                self.pattie_rect.y = 305
                self.surface.blit(self.pattie, self.pattie_rect)
            if burger[2] == 'lettuce':
                self.lettuce_rect.y = 300
                self.surface.blit(self.lettuce, self.lettuce_rect)
            if burger[2] == 'pickle':
                self.pickle_rect.y = 305
                self.surface.blit(self.pickle, self.pickle_rect)
            if burger[2] == 'cheese':
                self.cheese_rect.y = 300
                self.surface.blit(self.cheese, self.cheese_rect)

        if len(burger) > 3:
            if burger[3] == 'bun':
                self.bun_top_rect.y = 220
                self.surface.blit(self.bun_top, self.bun_top_rect)
            if burger[3] == 'tomato':
                self.tomato_rect.y = 285
                self.surface.blit(self.tomato, self.tomato_rect)
            if burger[3] == 'pattie':
                self.pattie_rect.y = 285
                self.surface.blit(self.pattie, self.pattie_rect)
            if burger[3] == 'lettuce':
                self.lettuce_rect.y = 280
                self.surface.blit(self.lettuce, self.lettuce_rect)
            if burger[3] == 'pickle':
                self.pickle_rect.y = 285
                self.surface.blit(self.pickle, self.pickle_rect)
            if burger[3] == 'cheese':
                self.cheese_rect.y = 280
                self.surface.blit(self.cheese, self.cheese_rect)

        if len(burger) > 4:
            if burger[4] == 'bun':
                self.bun_top_rect.y = 200
                self.surface.blit(self.bun_top, self.bun_top_rect)
            if burger[4] == 'tomato':
                self.tomato_rect.y = 265
                self.surface.blit(self.tomato, self.tomato_rect)
            if burger[4] == 'pattie':
                self.pattie_rect.y = 265
                self.surface.blit(self.pattie, self.pattie_rect)
            if burger[4] == 'lettuce':
                self.lettuce_rect.y = 260
                self.surface.blit(self.lettuce, self.lettuce_rect)
            if burger[4] == 'pickle':
                self.pickle_rect.y = 265
                self.surface.blit(self.pickle, self.pickle_rect)
            if burger[4] == 'cheese':
                self.cheese_rect.y = 260
                self.surface.blit(self.cheese, self.cheese_rect)

        if len(burger) > 5:
            if burger[5] == 'bun':
                self.bun_top_rect.y = 180
                self.surface.blit(self.bun_top, self.bun_top_rect)
            if burger[5] == 'tomato':
                self.tomato_rect.y = 245
                self.surface.blit(self.tomato, self.tomato_rect)
            if burger[5] == 'pattie':
                self.pattie_rect.y = 245
                self.surface.blit(self.pattie, self.pattie_rect)
            if burger[5] == 'lettuce':
                self.lettuce_rect.y = 240
                self.surface.blit(self.lettuce, self.lettuce_rect)
            if burger[5] == 'pickle':
                self.pickle_rect.y = 245
                self.surface.blit(self.pickle, self.pickle_rect)
            if burger[5] == 'cheese':
                self.cheese_rect.y = 240
                self.surface.blit(self.cheese, self.cheese_rect)

    def small_blit_burger(self, order_num, burger):
        if order_num == 0:
            self.red_soda_rect.centerx = 90
            self.large_fries_rect.centerx = 90
            self.small_bun_top_rect.centerx = 90
            self.small_cheese_rect.centerx = 90
            self.small_tomato_rect.centerx = 90
            self.small_pattie_rect.centerx = 90
            self.small_lettuce_rect.centerx = 90
            self.small_pickle_rect.centerx = 90
            self.small_bun_bottom_rect.centerx = 90
        if order_num == 1:
            self.large_fries_rect.centerx = 216
            self.red_soda_rect.centerx = 216
            self.small_bun_top_rect.centerx = 216
            self.small_cheese_rect.centerx = 216
            self.small_tomato_rect.centerx = 216
            self.small_pattie_rect.centerx = 216
            self.small_lettuce_rect.centerx = 216
            self.small_pickle_rect.centerx = 216
            self.small_bun_bottom_rect.centerx = 216
        if order_num == 2:
            self.large_fries_rect.centerx = 337
            self.red_soda_rect.centerx = 337
            self.small_bun_top_rect.centerx = 337
            self.small_cheese_rect.centerx = 337
            self.small_tomato_rect.centerx = 337
            self.small_pattie_rect.centerx = 337
            self.small_lettuce_rect.centerx = 337
            self.small_pickle_rect.centerx = 337
            self.small_bun_bottom_rect.centerx = 337
        if order_num == 3:
            self.large_fries_rect.centerx = 460
            self.red_soda_rect.centerx = 460
            self.small_bun_top_rect.centerx = 460
            self.small_cheese_rect.centerx = 460
            self.small_tomato_rect.centerx = 460
            self.small_pattie_rect.centerx = 460
            self.small_lettuce_rect.centerx = 460
            self.small_pickle_rect.centerx = 460
            self.small_bun_bottom_rect.centerx = 460
        if order_num == 4:
            self.large_fries_rect.centerx = 578
            self.red_soda_rect.centerx = 578
            self.small_bun_top_rect.centerx = 578
            self.small_cheese_rect.centerx = 578
            self.small_tomato_rect.centerx = 578
            self.small_pattie_rect.centerx = 578
            self.small_lettuce_rect.centerx = 578
            self.small_pickle_rect.centerx = 578
            self.small_bun_bottom_rect.centerx = 578
        if order_num == 5:
            self.large_fries_rect.centerx = 700
            self.red_soda_rect.centerx = 700
            self.small_bun_top_rect.centerx = 700
            self.small_cheese_rect.centerx = 700
            self.small_tomato_rect.centerx = 700
            self.small_pattie_rect.centerx = 700
            self.small_lettuce_rect.centerx = 700
            self.small_pickle_rect.centerx = 700
            self.small_bun_bottom_rect.centerx = 700
            
        if len(burger) > 0:
            if burger[0] == 'bun':
                self.small_bun_bottom_rect.y = 80
                self.surface.blit(self.small_bun_bottom, self.small_bun_bottom_rect)

            #Soda Blitting
            if burger[0] == 'red soda':
                self.surface.blit(self.red_soda, self.red_soda_rect)
            if burger[0] == 'blue soda':
                self.surface.blit(self.blue_soda, self.red_soda_rect)
            if burger[0] == 'green soda':
                self.surface.blit(self.green_soda, self.red_soda_rect)
            if burger[0] == 'yellow soda':
                self.surface.blit(self.yellow_soda, self.red_soda_rect)
            if burger[0] == 'orange soda':
                self.surface.blit(self.orange_soda, self.red_soda_rect)
            if burger[0] == 'purple soda':
                self.surface.blit(self.purple_soda, self.red_soda_rect) 

            #Fry blitting
            if burger[0] == 'large':
                self.surface.blit(self.large_fries, self.large_fries_rect)
            if burger[0] == 'medium':
                self.surface.blit(self.medium_fries, self.large_fries_rect)
            if burger[0] == 'small':
                self.surface.blit(self.small_fries, self.large_fries_rect)
                
        if len(burger) > 1:
            if burger[1] == 'bun':
                self.small_bun_top_rect.y = 35
                self.surface.blit(self.small_bun_top, self.small_bun_top_rect)
            if burger[1] == 'tomato':
                self.small_tomato_rect.y = 70
                self.surface.blit(self.small_tomato, self.small_tomato_rect)
            if burger[1] == 'pattie':
                self.small_pattie_rect.y = 70
                self.surface.blit(self.small_pattie, self.small_pattie_rect)
            if burger[1] == 'lettuce':
                self.small_lettuce_rect.y = 65
                self.surface.blit(self.small_lettuce, self.small_lettuce_rect)
            if burger[1] == 'pickle':
                self.small_pickle_rect.y = 70
                self.surface.blit(self.small_pickle, self.small_pickle_rect)
            if burger[1] == 'cheese':
                self.small_cheese_rect.y = 65
                self.surface.blit(self.small_cheese, self.small_cheese_rect)
                
        if len(burger) > 2:
            if burger[2] == 'bun':
                self.small_bun_top_rect.y = 25
                self.surface.blit(self.small_bun_top, self.small_bun_top_rect)
            if burger[2] == 'tomato':
                self.small_tomato_rect.y = 60
                self.surface.blit(self.small_tomato, self.small_tomato_rect)
            if burger[2] == 'pattie':
                self.small_pattie_rect.y = 60
                self.surface.blit(self.small_pattie, self.small_pattie_rect)
            if burger[2] == 'lettuce':
                self.small_lettuce_rect.y = 55
                self.surface.blit(self.small_lettuce, self.small_lettuce_rect)
            if burger[2] == 'pickle':
                self.small_pickle_rect.y = 60
                self.surface.blit(self.small_pickle, self.small_pickle_rect)
            if burger[2] == 'cheese':
                self.small_cheese_rect.y = 55
                self.surface.blit(self.small_cheese, self.small_cheese_rect)

        if len(burger) > 3:
            if burger[3] == 'bun':
                self.small_bun_top_rect.y = 20
                self.surface.blit(self.small_bun_top, self.small_bun_top_rect)
            if burger[3] == 'tomato':
                self.small_tomato_rect.y = 50
                self.surface.blit(self.small_tomato, self.small_tomato_rect)
            if burger[3] == 'pattie':
                self.small_pattie_rect.y = 50
                self.surface.blit(self.small_pattie, self.small_pattie_rect)
            if burger[3] == 'lettuce':
                self.small_lettuce_rect.y = 45
                self.surface.blit(self.small_lettuce, self.small_lettuce_rect)
            if burger[3] == 'pickle':
                self.small_pickle_rect.y = 50
                self.surface.blit(self.small_pickle, self.small_pickle_rect)
            if burger[3] == 'cheese':
                self.small_cheese_rect.y = 45
                self.surface.blit(self.small_cheese, self.small_cheese_rect)

        if len(burger) > 4:
            if burger[4] == 'bun':
                self.small_bun_top_rect.y = 10
                self.surface.blit(self.small_bun_top, self.small_bun_top_rect)
            if burger[4] == 'tomato':
                self.small_tomato_rect.y = 40
                self.surface.blit(self.small_tomato, self.small_tomato_rect)
            if burger[4] == 'pattie':
                self.small_pattie_rect.y = 40
                self.surface.blit(self.small_pattie, self.small_pattie_rect)
            if burger[4] == 'lettuce':
                self.small_lettuce_rect.y = 35
                self.surface.blit(self.small_lettuce, self.small_lettuce_rect)
            if burger[4] == 'pickle':
                self.small_pickle_rect.y = 40
                self.surface.blit(self.small_pickle, self.small_pickle_rect)
            if burger[4] == 'cheese':
                self.small_cheese_rect.y = 35
                self.surface.blit(self.small_cheese, self.small_cheese_rect)

        if len(burger) > 5:
            if burger[5] == 'bun':
                self.small_bun_top_rect.y = 5
                self.surface.blit(self.small_bun_top, self.small_bun_top_rect)
            if burger[5] == 'tomato':
                self.small_tomato_rect.y = 30
                self.surface.blit(self.small_tomato, self.small_tomato_rect)
            if burger[5] == 'pattie':
                self.small_pattie_rect.y = 30
                self.surface.blit(self.small_pattie, self.small_pattie_rect)
            if burger[5] == 'lettuce':
                self.small_lettuce_rect.y = 25
                self.surface.blit(self.small_lettuce, self.small_lettuce_rect)
            if burger[5] == 'pickle':
                self.small_pickle_rect.y = 30
                self.surface.blit(self.small_pickle, self.small_pickle_rect)
            if burger[5] == 'cheese':
                self.small_cheese_rect.y = 25
                self.surface.blit(self.small_cheese, self.small_cheese_rect)

