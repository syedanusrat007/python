#Menus
#By Tyler Spadgenske
NUM_OF_ORDERS = 6

import time, os, sys, pygame
from pygame.locals import *

pygame.init()

class Menu():
    def __init__(self, surface):
        self.ROOT_PATH = os.path.abspath('images')
        self.surface = surface
        #Setup some colors
        self.WHITE = (255,255,255)
        self.BLACK = (0,0,0)
        self.GAME_RED = (170,0,0)
        self.GREEN = (0,255,0)
        self.RED = (255,0,0)
        self.BLUE = (0,0,255)
        self.GREEN = (0,255,0)
        self.YELLOW = (255,255,0)
        self.PURPLE = (255,0,255)
        self.ORANGE = (255,123,0)
        self.CHEESE_YELLOW = (234,207,0)

        #Create top bar
        self.top_bar = {'rect':pygame.Rect(0, 0, 800, 150),'color':self.GAME_RED}

        #Setup fonts
        self.Font = pygame.font.SysFont(None, 18)
        self.friesFont = pygame.font.SysFont(None, 80)
        
        self.happiness = self.GREEN

        #Setup burger button
        self.burger_hover = False
        self.burger_clicked = False
        self.x = -30
        self.burger_button_image = pygame.image.load(os.path.join(self.ROOT_PATH, 'burger_button.png'))
        self.burger_button_rect = self.burger_button_image.get_rect()
        self.burger_button_rect.y = 200
        self.burger_button_rect.x = -30

        #Setup soda button
        self.soda_hover = False
        self.soda_clicked = False
        self.sodax = -30
        self.soda_button_image = pygame.image.load(os.path.join(self.ROOT_PATH, 'soda_button.png'))
        self.soda_button_rect = self.soda_button_image.get_rect()
        self.soda_button_rect.y = 200
        self.soda_button_rect.x = -30

        #Setup fries button
        self.fries_hover = False
        self.fries_clicked = False
        self.friesx = -30
        self.fries_button_image = pygame.image.load(os.path.join(self.ROOT_PATH, 'fries_button.png'))
        self.fries_button_rect = self.fries_button_image.get_rect()
        self.fries_button_rect.y = 200
        self.fries_button_rect.x = -30

        #Setup rect 
        self.rect_image = pygame.image.load(os.path.join(self.ROOT_PATH, 'rect.png'))
        self.rect = self.rect_image.get_rect()
        self.rect.y = 200
        self.rect.x = 640

        #Setup soda colors
        self.red = {'rect':pygame.Rect(662, 215, 30, 30),'color':self.RED}
        self.blue = {'rect':pygame.Rect(740, 215, 30, 30),'color':self.BLUE}
        self.green = {'rect':pygame.Rect(740, 285, 30, 30),'color':self.GREEN}
        self.yellow = {'rect':pygame.Rect(662, 285, 30, 30),'color':self.YELLOW}
        self.purple = {'rect':pygame.Rect(662, 355, 30, 30),'color':self.PURPLE}
        self.orange = {'rect':pygame.Rect(740, 355, 30, 30),'color':self.ORANGE}

        self.clicked = [None, None]

        #Create soda images
        self.red_soda = pygame.image.load(os.path.join(self.ROOT_PATH, 'red.png'))
        self.blue_soda = pygame.image.load(os.path.join(self.ROOT_PATH, 'blue.png'))
        self.green_soda = pygame.image.load(os.path.join(self.ROOT_PATH, 'green.png'))
        self.yellow_soda = pygame.image.load(os.path.join(self.ROOT_PATH, 'yellow.png'))
        self.orange_soda = pygame.image.load(os.path.join(self.ROOT_PATH, 'orange.png'))
        self.purple_soda = pygame.image.load(os.path.join(self.ROOT_PATH, 'purple.png'))
        self.soda_rect = self.red_soda.get_rect()
        self.soda_rect.y = 180
        self.soda_rect.centerx = self.surface.get_rect().centerx - 40

        #Setup fries images
        self.fries_image = pygame.image.load(os.path.join(self.ROOT_PATH, 'small.png'))
        self.fries_rect = self.fries_image.get_rect()
        self.fries_rect.y = 200
        self.fries_rect.x = 280
        self.fries_medium_image = pygame.image.load(os.path.join(self.ROOT_PATH, 'medium.png'))
        self.fries_medium_rect = self.fries_medium_image.get_rect()
        self.fries_medium_rect.y = 200
        self.fries_medium_rect.x = 280
        self.fries_large_image = pygame.image.load(os.path.join(self.ROOT_PATH, 'large.png'))
        self.fries_large_rect = self.fries_large_image.get_rect()
        self.fries_large_rect.y = 200
        self.fries_large_rect.x = 280

        #Setup fries size text
        self.small = self.friesFont.render('S', True, self.GAME_RED, self.WHITE)
        self.smallRect = self.small.get_rect()
        self.smallRect.centerx = 752
        self.smallRect.centery = 235

        self.medium = self.friesFont.render('M', True, self.GAME_RED, self.WHITE)
        self.mediumRect = self.medium.get_rect()
        self.mediumRect.centerx = 752
        self.mediumRect.centery = 302

        self.large = self.friesFont.render('L', True, self.GAME_RED, self.WHITE)
        self.largeRect = self.large.get_rect()
        self.largeRect.centerx = 752
        self.largeRect.centery = 370

        #Create bun image
        self.small_bun = pygame.image.load(os.path.join(self.ROOT_PATH, 'bun-top.png'))
        self.small_bun_rect = self.small_bun.get_rect()
        self.small_bun_rect.y = 220
        self.small_bun_rect.x = 727

        #Create pattie image
        self.small_pattie = pygame.image.load(os.path.join(self.ROOT_PATH, 'small-pattie.png'))
        self.small_pattie_rect = self.small_pattie.get_rect()
        self.small_pattie_rect.y = 208
        self.small_pattie_rect.x = 651

        #Create cheese rect
        self.small_cheese = pygame.image.load(os.path.join(self.ROOT_PATH, 'small-cheese.png'))
        self.small_cheese_rect = self.small_cheese.get_rect()
        self.small_cheese_rect.y = 280
        self.small_cheese_rect.x = 651


        #Create tomato image
        self.small_tomato = pygame.image.load(os.path.join(self.ROOT_PATH, 'small-tomato.png'))
        self.small_tomato_rect = self.small_tomato.get_rect()
        self.small_tomato_rect.y = 280
        self.small_tomato_rect.x = 727

        #Create lettuce image
        self.small_lettuce = pygame.image.load(os.path.join(self.ROOT_PATH, 'small-lettuce.png'))
        self.small_lettuce_rect = self.small_lettuce.get_rect()
        self.small_lettuce_rect.y = 340
        self.small_lettuce_rect.x = 727

        #Create pickle image
        self.small_pickle = pygame.image.load(os.path.join(self.ROOT_PATH, 'small-pickle.png'))
        self.small_pickle_rect = self.small_pickle.get_rect()
        self.small_pickle_rect.y = 340
        self.small_pickle_rect.x = 648

        self.burger = []

        self.completed_customers = 10
        self.order_clicked = None
        
    def blit_orders(self):
        pygame.draw.rect(self.surface, self.top_bar['color'], self.top_bar['rect'])
        for i in range(0, NUM_OF_ORDERS):
            pygame.draw.rect(self.surface, self.WHITE, pygame.Rect(i * 120 + 3 * i + 30, 3, 120, 120))
        for i in range(0, NUM_OF_ORDERS):
            pass
            #pygame.draw.rect(self.surface, self.WHITE, pygame.Rect(i * 120 + 3 * i + 30, 126, 120, 20))

    def bottom_menu(self, timeLeft, remainingCustomers, completedBurgers):
        #Black bottom bar
        self.bottom_bar = {'rect':pygame.Rect(0, 460, 800, 20),'color':self.GAME_RED}
        pygame.draw.rect(self.surface, self.bottom_bar['color'], self.bottom_bar['rect'])

        #Burgers completed text
        self.served = self.Font.render('Meals Served: ' + str(completedBurgers), True, self.WHITE, self.GAME_RED)
        self.servedRect = self.served.get_rect()
        self.servedRect.centerx = 70
        self.servedRect.centery = 470
        self.surface.blit(self.served, self.servedRect)

        #Customers remaining text
        self.remain = self.Font.render('Customers Remaining: ' + str(remainingCustomers), True, self.WHITE, self.GAME_RED)
        self.remainRect = self.remain.get_rect()
        self.remainRect.centerx = self.surface.get_rect().centerx
        self.remainRect.centery = 470
        self.surface.blit(self.remain, self.remainRect)

        #Time Left text
        self.time = self.Font.render('Time Left: ' + str(timeLeft[0]) + ':' + str(timeLeft[1]), True, self.WHITE, self.GAME_RED)
        self.timeRect = self.remain.get_rect()
        self.timeRect.centerx = 765
        self.timeRect.centery = 470
        self.surface.blit(self.time, self.timeRect)

    def burger_menu(self, mode, event=None):
        self.burger_button_rect = self.burger_button_image.get_rect()
        self.burger_button_rect.y = 200
        self.burger_button_rect.x = self.x
        self.surface.blit(self.burger_button_image, self.burger_button_rect)

        if event != None:
            if event.type == MOUSEMOTION:
                if event.pos[0] > 0 and event.pos[0] < 57 and event.pos[1] > 200 and event.pos[1] < 250:
                    self.burger_hover = True
                else:
                    self.burger_hover = False

            if event.type == MOUSEBUTTONDOWN:
                if event.pos[0] > 0 and event.pos[0] < 86 and event.pos[1] > 200 and event.pos[1] < 250:
                    self.burger_clicked = True
                    
        if self.burger_hover:
            self.x = 0
        else:
            self.x = -30
        if self.burger_clicked:
            self.clicked = [None, None]
            self.burger = []
            self.burger_clicked = False
            return 'burger'
        else:
            return mode

    def soda_menu(self, mode, event=None):
        self.soda_button_rect = self.soda_button_image.get_rect()
        self.soda_button_rect.y = 260
        self.soda_button_rect.x = self.sodax
        self.surface.blit(self.soda_button_image, self.soda_button_rect)

        if event != None:
            if event.type == MOUSEMOTION:
                if event.pos[0] > 0 and event.pos[0] < 57 and event.pos[1] > 260 and event.pos[1] < 310:
                    self.soda_hover = True
                else:
                    self.soda_hover = False

            if event.type == MOUSEBUTTONDOWN:
                if event.pos[0] > 0 and event.pos[0] < 86 and event.pos[1] > 260 and event.pos[1] < 310:
                    self.soda_clicked = True
                    
        if self.soda_hover:
            self.sodax = 0
        else:
            self.sodax = -30
        if self.soda_clicked:
            self.clicked = [None, None]
            self.burger = []
            self.soda_clicked = False
            return 'soda'
        else:
            return mode

    def fries_menu(self, mode, event=None):
        self.fries_button_rect = self.fries_button_image.get_rect()
        self.fries_button_rect.y = 320
        self.fries_button_rect.x = self.friesx
        self.surface.blit(self.fries_button_image, self.fries_button_rect)

        if event != None:
            if event.type == MOUSEMOTION:
                if event.pos[0] > 0 and event.pos[0] < 57 and event.pos[1] > 320 and event.pos[1] < 370:
                    self.fries_hover = True
                else:
                    self.fries_hover = False

            if event.type == MOUSEBUTTONDOWN:
                if event.pos[0] > 0 and event.pos[0] < 86 and event.pos[1] > 320 and event.pos[1] < 370:
                    self.fries_clicked = True
                    
        if self.fries_hover:
            self.friesx = 0
        else:
            self.friesx = -30
        if self.fries_clicked:
            self.fries_clicked = False
            self.burger = []
            self.clicked = [None, None]
            return 'fries'
        else:
            return mode
    
    def select(self, mode, burger, event=None):
        self.surface.blit(self.rect_image, self.rect)
        self.burger = burger

        if mode == 'soda':
            pygame.draw.rect(self.surface, self.red['color'], self.red['rect'])
            pygame.draw.rect(self.surface, self.blue['color'], self.blue['rect'])
            pygame.draw.rect(self.surface, self.green['color'], self.green['rect'])
            pygame.draw.rect(self.surface, self.yellow['color'], self.yellow['rect'])
            pygame.draw.rect(self.surface, self.purple['color'], self.purple['rect'])
            pygame.draw.rect(self.surface, self.orange['color'], self.orange['rect'])

            if self.clicked == [0, 0]:
                self.burger = ['red soda']
            if self.clicked == [1, 0]:
                self.burger = ['blue soda']
            if self.clicked == [1, 1]:
                self.burger = ['green soda']
            if self.clicked == [0, 1]:
                self.burger = ['yellow soda']
            if self.clicked == [0, 2]:
                self.burger = ['purple soda']
            if self.clicked == [1, 2]:
                self.burger = ['orange soda']

            if self.burger == ['red soda']:
                self.surface.blit(self.red_soda, self.soda_rect)
            if self.burger == ['blue soda']:
                self.surface.blit(self.blue_soda, self.soda_rect)
            if self.burger == ['green soda']:
                self.surface.blit(self.green_soda, self.soda_rect)
            if self.burger == ['yellow soda']:
                self.surface.blit(self.yellow_soda, self.soda_rect)
            if self.burger == ['orange soda']:
                self.surface.blit(self.orange_soda, self.soda_rect)
            if self.burger == ['purple soda']:
                self.surface.blit(self.purple_soda, self.soda_rect)
            
            

        if mode == 'fries':
            self.surface.blit(self.small, self.smallRect)
            self.surface.blit(self.medium, self.mediumRect)
            self.surface.blit(self.large, self.largeRect)
            if self.clicked == [1,0]:
                self.burger = ['small']
                self.surface.blit(self.fries_image, self.fries_rect)
            if self.clicked == [1, 1]:
                self.surface.blit(self.fries_medium_image, self.fries_medium_rect)
                self.burger = ['medium']
            if self.clicked == [1, 2]:
                self.surface.blit(self.fries_large_image, self.fries_large_rect)
                self.burger = ['large']
        if mode == 'burger':
            self.surface.blit(self.small_bun, self.small_bun_rect)
            self.surface.blit(self.small_pattie, self.small_pattie_rect)
            self.surface.blit(self.small_cheese, self.small_cheese_rect)
            self.surface.blit(self.small_tomato, self.small_tomato_rect)
            self.surface.blit(self.small_lettuce, self.small_lettuce_rect)
            self.surface.blit(self.small_pickle, self.small_pickle_rect)

            if self.clicked == [0,0]:
                self.burger.append('pattie')
                self.clicked = [None, None]
            if self.clicked == [1,0]:
                self.burger.append('bun')
                self.clicked = [None, None]
            if self.clicked == [0,1]:
                self.burger.append('cheese')
                self.clicked = [None, None]
            if self.clicked == [1,1]:
                self.burger.append('tomato')
                self.clicked = [None, None]
            if self.clicked == [0,2]:
                self.burger.append('pickle')
                self.clicked = [None, None]
            if self.clicked == [1,2]:
                self.burger.append('lettuce')
                self.clicked = [None, None]
                
        if event != None:
            if event.type == MOUSEBUTTONDOWN:
                #box x0 y0
                if event.pos[0] > 639 and event.pos[0] < 715 and event.pos[1] > 200 and event.pos[1] < 269:
                    self.clicked = [0,0]
                #box x1 y0
                if event.pos[0] > 715 and event.pos[0] < 790 and event.pos[1] > 200 and event.pos[1] < 269:
                    self.clicked = [1,0]
                #box x1 y1
                if event.pos[0] > 715 and event.pos[0] < 790 and event.pos[1] > 269 and event.pos[1] < 335:
                    self.clicked = [1,1]
                #box x0 y1
                if event.pos[0] > 639 and event.pos[0] < 715 and event.pos[1] > 269 and event.pos[1] < 335:
                    self.clicked = [0,1]
                #box x1 y2
                if event.pos[0] > 715 and event.pos[0] < 790 and event.pos[1] > 335 and event.pos[1] < 401:
                    self.clicked = [1,2]
                #box x0 y2
                if event.pos[0] > 639 and event.pos[0] < 715 and event.pos[1] > 335 and event.pos[1] < 401:
                    self.clicked = [0,2]

        return self.burger

    def order_button(self, event):
        self.order_clicked = None
        if event.type == MOUSEBUTTONDOWN:
                if event.pos[0] > 30 and event.pos[0] < 150 and event.pos[1] > 3 and event.pos[1] < 120:
                    self.order_clicked = 0
                if event.pos[0] > 150 and event.pos[0] < 270 and event.pos[1] > 3 and event.pos[1] < 120:
                    self.order_clicked = 1
                if event.pos[0] > 270 and event.pos[0] < 390 and event.pos[1] > 3 and event.pos[1] < 120:
                    self.order_clicked = 2
                if event.pos[0] > 390 and event.pos[0] < 510 and event.pos[1] > 3 and event.pos[1] < 120:
                    self.order_clicked = 3
                if event.pos[0] > 510 and event.pos[0] < 630 and event.pos[1] > 3 and event.pos[1] < 120:
                    self.order_clicked = 4
                if event.pos[0] > 630 and event.pos[0] < 750 and event.pos[1] > 3 and event.pos[1] < 120:
                    self.order_clicked = 5
        
