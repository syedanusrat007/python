Fast Food
=========

Deliver Food as Fast as You Can to Waiting Customers.


How to play:

After the game loads, press enter to start.

Choose what meal you would like to serve. Meals are the top row or either: Burgers, sodas, or fries.

For serving burgers:
1. Click on the Burger tab.
2. Click on the toppings your burger requires.
3. Click on the customer. If the burgers match, you score and continue.

For serving soda:
1. Click on the soda tab.
2. Click on the color of the soda you are serving.
3. Click on the person you are giving the soda.

For serving fries:
1. Click on the fries tab.
2. Click on the size of the fries.
3. Click on the person you are giving the fries.

If you serve the amount of burgers required before the time runs up, you continue on. Otherwise you
lose. If you like the game, please give me a award at https://pyweek.org/e/Fast-Food/ 
Code is also on GitHub:
https://github.com/spadgenske/Fast-Food