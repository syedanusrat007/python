#Generate
#By Tyler Spadgenske
import random

class Gen():

    def __init__(self):
        self.reset()
        self.toppings = ['pattie', 'tomato', 'cheese', 'lettuce', 'bun', 'pickle']
        self.menu = ['burger', 'soda', 'burger', 'fries', 'burger']
        self.sodas = ['red soda', 'blue soda', 'yellow soda', 'green soda', 'orange soda', 'purple soda']
        self.fries = ['large', 'medium', 'small']
    def generate(self):
        self.order = random.choice(self.menu)
        if self.order == 'burger':
            self.burger.append('bun')
            for i in range(0, 4):
                new_topping = random.choice(self.toppings)
                if new_topping != 'bun':
                    self.burger.append(new_topping)
                else:
                    if random.randrange(1) == 0:
                        if len(self.burger) > 3:
                            self.burger.append('bun')
                            self.short = True
                            break
            if self.short == False:
                self.burger.append('bun')
                
        if self.order == 'soda':
            self.short = True
            self.burger = [random.choice(self.sodas)]
        if self.order == 'fries':
            self.short = True
            self.burger = [random.choice(self.fries)]

        self.backup = self.burger
        self.reset()
        return self.backup

    def reset(self):
        self.burger = []
        self.short = False
