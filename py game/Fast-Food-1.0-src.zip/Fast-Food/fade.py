#Fading
#By Tyler Spadgenske

import pygame
from pygame.locals import *
import sys, time
pygame.init()

class Fade():
    def __init__(self, surface):
        self.WHITE = (255,255,255)
        self.GAME_RED = (170,0,0)
        self.num2 = 255
        self.screen = surface
        self.dim = pygame.Surface((800,608))        
        self.dim.fill(self.GAME_RED)
        self.clock = pygame.time.Clock()
        self.first = True

        self.num = 0

        self.start_time = time.time()
        
        self.font = pygame.font.SysFont(None, 58)
        self.small_font = pygame.font.SysFont(None, 29)

        self.start_time2 = time.time()
        self.sec = True
        
    def fade_out(self, served):
        self.first = False
        self.num += .5
        self.dim.set_alpha(self.num)
        self.screen.blit(self.dim, (0,0))

        if self.num > 255:
            self.first = True
            
        if self.first:
            if self.sec:
                self.start_time2 = time.time()
                self.sec = False
            self.level = self.font.render('Game Over', True, self.WHITE, self.GAME_RED)
            self.levelRect = self.level.get_rect()
            self.levelRect.centerx = self.screen.get_rect().centerx
            self.levelRect.centery = self.screen.get_rect().centery

            self.score = self.small_font.render('Meals Served: ' + str(served), True, self.WHITE, self.GAME_RED)
            self.scoreRect = self.score.get_rect()
            self.scoreRect.centerx = self.screen.get_rect().centerx
            self.scoreRect.centery = self.screen.get_rect().centery + 50
            
            self.screen.blit(self.dim, (0,0)) 
            self.screen.blit(self.level, self.levelRect)
            self.screen.blit(self.score, self.scoreRect)

    def fade_in(self, level):
        if self.first:
            self.level = self.font.render('Level ' + str(level), True, self.WHITE, self.GAME_RED)
            self.levelRect = self.level.get_rect()
            self.levelRect.centerx = self.screen.get_rect().centerx
            self.levelRect.centery = self.screen.get_rect().centery
            self.screen.blit(self.dim, (0,0)) 
            self.screen.blit(self.level, self.levelRect)
            
        else:
            self.num2 -= .5
            self.dim.set_alpha(self.num2)
            self.screen.blit(self.dim, (0,0))
        return level

    def start_new_level(self, level):
        level += 1
        while True:
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()

            pygame.display.update()
            self.screen.fill(self.WHITE)
            self.clock.tick()

            level = self.fade_in(level)

            if time.time() - self.start_time > 2:
                self.first = False
            if time.time() -  self.start_time > 3:
                break
        return level
    
    def game_over(self, served):
        while True:
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()

            pygame.display.update()
            self.screen.fill(self.WHITE)
            self.clock.tick()

            self.fade_out(served)

            if self.sec == False:
                if time.time() - self.start_time2 > 6:
                    self.sec = True
                    break

