#New Order
#By Tyler Spadgenske
import random

class Order():
    def __init__(self):
        self.toppings = ['cheese', 'pattie', 'tomato', 'pickle', 'lettuce', 'bun']
        self.burger = []
        self.short = False
        
    def generate(self):
        self.burger.append('bun')
        for i in range(0, 4):
            new_topping = random.choice(self.toppings)
            if new_topping != 'bun':
                self.burger.append(new_topping)
            else:
                if random.randrange(1) == 0:
                    self.burger.append('bun')
                    self.short = True
                    break

        if self.short == False:
            self.burger.append('bun')
        print self.burger
        return self.burger
        self.reset()

    def reset(self):
        self.burger = []
        self.short = False
  
        
