# bunnies-and-badgers

A simple game in python where the hero, the bunny, has to defend a castle against an attacking horde of badgers.

## How to play?

  1. Install [Python](http://www.python.org/download/). Make sure you grab the 2.7.x version and NOT the 3.3.x version!
  2. Download the [PyGame](http://www.pygame.org/download.shtml) installer appropriate for your system. Make sure you download a Python 2.7 version.

To verify that you have configured your system correctly, open IDLE or run Python via the Terminal and type in "import pygame" at the python prompt. If this doesn't result in any output, then you're all set up and good to go. If, on the other hand, it outputs an error, then PyGame is not installed or not set up correctly.
